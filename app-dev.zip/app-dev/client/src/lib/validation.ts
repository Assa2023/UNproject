import { z } from "zod";

export const projectSchema = z.object({
  projectId: z.number({
    required_error: "Project ID is required",
  }),
  projectTitle: z.string().min(1, "Project title is required"),
  paasCode: z.string().optional(),
  approvalStatus: z.string().optional(),
  fund: z.string().optional(),
  pagValue: z.string().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  country: z.string().optional(),
  LeadOrgUnit: z.string().optional(),
  Theme: z.string().optional(),
  Donor: z.string().optional(),
  TotalExpenditure: z.string().optional(),
  TotalContribution: z.string().optional(),
  TC_TE: z.string().optional(),
  TotalPSC: z.string().optional(),
});

export type ProjectFormValues = z.infer<typeof projectSchema>;
