import { type ColumnDef } from "@tanstack/react-table";
import { MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// This type matches the MongoDB schema structure
export type ProjectRecord = {
  projectId: number;
  projectTitle: string;
  paasCode: string;
  approvalStatus: string;
  fund: string;
  pagValue: string;
  startDate: string;
  endDate: string;
  country: string;
  LeadOrgUnit: string;
  Theme: string;
  Donor: string;
  TotalExpenditure: string;
  TotalContribution: string;
  TC_TE: string;
  TotalPSC: string;
};

export const columns: ColumnDef<ProjectRecord>[] = [
  {
    id: "actions",
    cell: ({ row }) => {
      const record = row.original;

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => {
                // Dispatch custom event to show the update form
                const event = new CustomEvent("showUpdateForm", {
                  detail: record,
                });
                window.dispatchEvent(event);
              }}
            >
              Update
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => {
                // Dispatch custom event to show the delete confirmation
                const event = new CustomEvent("showDeleteConfirmation", {
                  detail: record,
                });
                window.dispatchEvent(event);
              }}
              className="text-destructive focus:bg-destructive/10"
            >
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
  {
    accessorKey: "projectId",
    header: "ID",
  },
  {
    accessorKey: "projectTitle",
    header: "Project Title",
  },
  {
    accessorKey: "paasCode",
    header: "PAAS Code",
  },
  {
    accessorKey: "approvalStatus",
    header: "Status",
  },
  {
    accessorKey: "fund",
    header: "Fund",
  },
  {
    accessorKey: "pagValue",
    header: "PAG Value",
  },
  {
    accessorKey: "country",
    header: "Country",
  },
  {
    accessorKey: "LeadOrgUnit",
    header: "Lead Org Unit",
  },
  {
    accessorKey: "Donor",
    header: "Donor",
  },
  {
    accessorKey: "TotalExpenditure",
    header: "Total Expenditure",
  },
  {
    accessorKey: "TotalContribution",
    header: "Total Contribution",
  },
  {
    accessorKey: "TC_TE",
    header: "TC - TE",
  },
  {
    accessorKey: "TotalPSC",
    header: "Total PSC",
  },
];
