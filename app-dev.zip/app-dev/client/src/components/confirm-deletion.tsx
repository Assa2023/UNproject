import { useState } from "react";
import axios from "axios";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { type ProjectRecord } from "@/components/column";

interface ConfirmDeletionProps {
  record: ProjectRecord;
  onClose: () => void;
  onSuccess: () => void;
}

export function ConfirmDeletion({
  record,
  onClose,
  onSuccess,
}: ConfirmDeletionProps) {
  const [isDeleting, setIsDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDelete = async () => {
    try {
      setIsDeleting(true);
      setError(null);

      await axios.delete(
        `http://localhost:4000/api/v1/app/${record.projectId}`
      );

      onSuccess();
      onClose();
    } catch (err) {
      console.error("Error deleting record:", err);
      setError("Failed to delete record. Please try again.");
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="fixed inset-0" onClick={onClose}></div>
      <Card className="w-full max-w-md relative">
        <CardHeader>
          <CardTitle>Confirm Deletion</CardTitle>
          <CardDescription>
            Are you sure you want to delete this record? This action cannot be
            undone.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <div className="mt-4 p-2 bg-destructive/20 text-destructive rounded-md text-sm">
              {error}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} disabled={isDeleting}>
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={handleDelete}
            disabled={isDeleting}
          >
            {isDeleting ? "Deleting..." : "Delete"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
