import { useState, useEffect } from "react";
import axios from "axios";
import { DataTable } from "./components/data-table";
import { columns, type ProjectRecord } from "./components/column";
import { ConfirmDeletion } from "./components/confirm-deletion";
import { UpdatingForm } from "./components/updating-form";

function App() {
  const [data, setData] = useState<ProjectRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [showUpdateForm, setShowUpdateForm] = useState(false);
  const [recordToDelete, setRecordToDelete] = useState<ProjectRecord | null>(
    null
  );
  const [recordToUpdate, setRecordToUpdate] = useState<ProjectRecord | null>(
    null
  );

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    // Listen for the custom event for delete confirmation
    const handleShowDeleteConfirmation = (
      event: CustomEvent<ProjectRecord>
    ) => {
      setRecordToDelete(event.detail);
      setShowDeleteConfirmation(true);
    };

    // Listen for the custom event for update form
    const handleShowUpdateForm = (event: CustomEvent<ProjectRecord>) => {
      setRecordToUpdate(event.detail);
      setShowUpdateForm(true);
    };

    window.addEventListener(
      "showDeleteConfirmation",
      handleShowDeleteConfirmation as EventListener
    );

    window.addEventListener(
      "showUpdateForm",
      handleShowUpdateForm as EventListener
    );

    return () => {
      window.removeEventListener(
        "showDeleteConfirmation",
        handleShowDeleteConfirmation as EventListener
      );

      window.removeEventListener(
        "showUpdateForm",
        handleShowUpdateForm as EventListener
      );
    };
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await axios.get("http://localhost:4000/api/v1/app");
      setData(response.data);
      setError(null);
    } catch (err) {
      console.error("Error fetching data:", err);
      setError("Failed to load records. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteSuccess = () => {
    fetchData();
  };

  const handleUpdateSuccess = () => {
    fetchData();
  };

  const handleCloseDeleteModal = () => {
    setShowDeleteConfirmation(false);
    setRecordToDelete(null);
  };

  const handleCloseUpdateModal = () => {
    setShowUpdateForm(false);
    setRecordToUpdate(null);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
      <div className="w-full max-w-7xl space-y-6">
        <h1 className="font-bold text-2xl text-center mb-6">Records</h1>

        {error && (
          <div className="p-4 bg-destructive/20 text-destructive rounded-md text-center">
            {error}
          </div>
        )}

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-pulse text-lg">Loading records...</div>
          </div>
        ) : (
          <DataTable columns={columns} data={data} />
        )}
      </div>

      {showDeleteConfirmation && recordToDelete && (
        <ConfirmDeletion
          record={recordToDelete}
          onClose={handleCloseDeleteModal}
          onSuccess={handleDeleteSuccess}
        />
      )}

      {showUpdateForm && recordToUpdate && (
        <UpdatingForm
          record={recordToUpdate}
          onClose={handleCloseUpdateModal}
          onSuccess={handleUpdateSuccess}
        />
      )}
    </div>
  );
}

export default App;
