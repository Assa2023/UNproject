const express = require("express");
const router = express.Router();

const {
  addNewRecord,
  getRecords,
  deleteRecord,
  updateRecord,
} = require("../controllers/app");

router.route("/").post(addNewRecord).get(getRecords);

router.route("/:projectId").delete(deleteRecord).put(updateRecord);

module.exports = router;
