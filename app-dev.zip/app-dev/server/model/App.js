const mongoose = require("mongoose");

const AppSchema = mongoose.Schema({
  projectId: {
    type: Number,
    required: true,
  },
  projectTitle: {
    type: String,
  },
  paasCode: {
    type: String,
  },
  approvalStatus: {
    type: String,
  },
  fund: {
    type: String,
  },
  pagValue: {
    type: String,
  },
  startDate: {
    type: String,
  },
  endDate: {
    type: String,
  },
  country: {
    type: String,
  },
  LeadOrgUnit: {
    type: String,
  },
  Theme: {
    type: String,
  },
  Donor: {
    type: String,
  },
  TotalExpenditure: {
    type: String,
  },
  TotalContribution: {
    type: String,
  },
  TC_TE: {
    type: String,
  },
  TotalPSC: {
    type: String,
  },
});

const AppModel = mongoose.model("App", AppSchema);

module.exports = AppModel;
