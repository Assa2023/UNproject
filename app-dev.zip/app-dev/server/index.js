const express = require("express");
const app = express();
const cors = require("cors");
const connectDB = require("./db/connect");
const appRouter = require("./routes/app-routes");
// const { importCsvToMongoDB } = require("./util/csv_bulk_insertions");
require("dotenv").config();

app.use(cors());
app.use(express.json());

app.get("/api/v1/test", (req, res) => {
  res.json("Test Ok");
});

app.use("/api/v1/app", appRouter);

const port = process.env.PORT || 4000;

const start = async () => {
  try {
    await connectDB(process.env.MONGO_URI);
    console.log("Connected to DB");

    app.listen(port, () =>
      console.log(`Server is listening on port ${port}...`)
    );
    // const result = await importCsvToMongoDB("./data.csv", 800, (message) =>
    //   console.log(message)
    // );

    // if (result.success) {
    //   console.log(
    //     `Batch processing successful: ${result.count} records imported`
    //   );
    // } else {
    //   console.error("Batch processing failed:", result.error);
    // }
  } catch (error) {
    console.log(error);
  }
};

start();
