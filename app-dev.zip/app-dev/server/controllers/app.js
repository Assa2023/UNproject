const App = require("../model/App");

const addNewRecord = async (req, res) => {
  const {
    projectId,
    projectTitle,
    paasCode,
    approvalStatus,
    fund,
    pagValue,
    startDate,
    endDate,
    country,
    LeadOrgUnit,
    Theme,
    Donor,
    TotalExpenditure,
    TotalContribution,
    TC_TE,
    TotalPSC,
  } = req.body;

  try {
    const record = await App.create({
      projectId,
      projectTitle,
      paasCode,
      approvalStatus,
      fund,
      pagValue,
      startDate,
      endDate,
      country,
      LeadOrgUnit,
      Theme,
      Donor,
      TotalExpenditure,
      TotalContribution,
      TC_TE,
      TotalPSC,
    });

    res.status(201).json(record);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const getRecords = async (req, res) => {
  try {
    const record = await App.find();
    res.json(record);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const deleteRecord = async (req, res) => {
  try {
    const { projectId } = req.params;

    const result = await App.deleteOne({ projectId });

    if (result.deletedCount === 0) {
      return res
        .status(404)
        .json({ message: `Record with id: ${projectId} not found` });
    }

    res.json({
      projectId,
      msg: `Record of id: ${projectId} has been deleted successfully`,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const updateRecord = async (req, res) => {
  try {
    const { projectId } = req.params;

    const updatedData = req.body;

    const updatedRecord = await App.findOneAndUpdate(
      { projectId },
      updatedData,
      { new: true, runValidators: true }
    );

    if (!updatedRecord) {
      return res
        .status(404)
        .json({ message: `Record with id: ${projectId} not found` });
    }

    res.json(updatedRecord);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

module.exports = {
  addNewRecord,
  getRecords,
  deleteRecord,
  updateRecord,
};
