const fs = require("fs");
const csv = require("csv-parser");
const App = require("../model/App");

const importCsvToMongoDB = async (
  filePath,
  batchSize = 800,
  progressCallback = null
) => {
  try {
    let batch = [];
    let totalImported = 0;

    return new Promise((resolve, reject) => {
      fs.createReadStream(filePath)
        .pipe(csv())
        .on("data", (data) => {
          // Skip empty rows or rows without projectId
          if (
            !data[Object.keys(data)[0]] ||
            isNaN(parseInt(data[Object.keys(data)[0]]))
          ) {
            return;
          }

          // Map CSV columns to schema fields
          const project = {
            projectId: parseInt(data[Object.keys(data)[0]]) || 0,
            projectTitle: data[Object.keys(data)[1]] || "",
            paasCode: data[Object.keys(data)[2]] || "",
            approvalStatus: data[Object.keys(data)[3]] || "",
            fund: data[Object.keys(data)[4]] || "",
            pagValue: data[Object.keys(data)[5]] || "",
            startDate: data[Object.keys(data)[6]] || "",
            endDate: data[Object.keys(data)[7]] || "",
            country: data[Object.keys(data)[8]] || "",
            LeadOrgUnit: data[Object.keys(data)[9]] || "",
            Theme: data[Object.keys(data)[10]] || "",
            Donor: data[Object.keys(data)[11]] || "",
            TotalExpenditure: data[Object.keys(data)[12]] || "",
            TotalContribution: data[Object.keys(data)[13]] || "",
            TC_TE: data[Object.keys(data)[14]] || "",
            TotalPSC: data[Object.keys(data)[15]] || "",
          };

          batch.push(project);

          // Process in batches
          if (batch.length >= batchSize) {
            processBatch(batch, progressCallback)
              .then((count) => {
                totalImported += count;
                if (progressCallback)
                  progressCallback(`Processed ${totalImported} records so far`);
                batch = [];
              })
              .catch((error) => reject(error));
          }
        })
        .on("end", async () => {
          try {
            // Process any remaining records
            if (batch.length > 0) {
              const count = await processBatch(batch, progressCallback);
              totalImported += count;
            }

            if (progressCallback)
              progressCallback(
                `CSV batch processing complete. Total records imported: ${totalImported}`
              );
            resolve({ success: true, count: totalImported });
          } catch (error) {
            reject(error);
          }
        })
        .on("error", (error) => {
          reject(error);
        });
    });
  } catch (error) {
    return { success: false, count: 0, error };
  }
};

async function processBatch(batch, progressCallback) {
  if (batch.length === 0) return 0;

  try {
    await App.insertMany(batch);
    return batch.length;
  } catch (error) {
    if (progressCallback)
      progressCallback(`Error during batch insert: ${error.message}`);
    throw error;
  }
}

module.exports = { importCsvToMongoDB };
